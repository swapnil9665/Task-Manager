COMMERCIAL BUILDING ENERGY FORECAST - PRACTICE DATA

Files:
- data/building_train.csv   : training data with energy_consumed_kwh target
- data/building_test.csv    : held-back test data with target
- data/building_predict.csv : scheduled future records; target column intentionally absent

The datasets are synthetic and intended for practicing the attached assignment.
They include deliberate data-quality issues:
- one duplicate reading_id in each file
- one invalid reading_ts in each file
- missing numeric feature values
- inconsistent capitalization/spacing in categorical columns

After removing the duplicate and invalid timestamp row, the expected row counts are:
- train: 4200
- test: 1000
- predict: 300

The exact model metrics will differ from the PDF's illustrative values.
